/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 * @module highcharts/modules/parallel-coordinates
 * @requires highcharts
 *
 * Support for parallel coordinates in Highcharts
 *
 * (c) 2010-2019 Pawel Fus
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/parallel-coordinates.src.js';
