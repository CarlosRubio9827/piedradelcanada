<footer class="page-footer text-center font-small">
 <div class="pt-1">
    </div>
<hr class="my-1">
<div class="pb-2">
    Desarrollado por <img src="../../assets/img/dashboard/state/Rupinsisinfondo.png" alt="">
</div>

<div class="footer-copyright py-3">
    Copyright© <?php echo date('Y') ?> - Todos los derechos reservados
</div>
</footer-->
<script type="text/javascript" src="../../assets/js/addons/moment.js"></script>
<script type="text/javascript" src="../../assets/js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="../../assets/js/popper.min.js"></script>
<script type="text/javascript" src="../../assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../../assets/js/font-awesome.all.js"></script>
<script type="text/javascript" src="../../assets/js/mdb.min.js"></script>
<script type="text/javascript" src="../../assets/js/sweet.min.js"></script>

